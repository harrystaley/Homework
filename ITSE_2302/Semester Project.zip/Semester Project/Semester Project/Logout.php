<?php 
session_start();
session_destroy();
?>

<html>
    <head>
        <title> Fred’s Market Biz Logout</title>
        <link rel="stylesheet" type="text/css" href="Style.css" />
        <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    </head>
    <body>
    Logout Successful <br>
    To log back in click the link below <br>
    <a href="LoginPage.php">Log Back In</a>
    </body>
</html>