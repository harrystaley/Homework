<html>
    <head>
        <title>Guest Book Alphabetizeation</title>
    </head> 
    <body> 
        
        <p>
            <h1>The guest book has been alphabetized.</h1>
        </p>
        <p>
            <p><a href ="ShowGuestBook.php">Show Guest Book. </a></p>
            <p><a href ="AlphaGuestBook.php">Remove duplicate values and alphabatize the Guest Book. </a></p>
            <p><a href ="GuestBook.html">Add another guest to the Guest Book. </a></p>
            
        </p>
    </head>
</html>



<?php
$GuestBook = fopen('GuestBook.csv', 'r') or die('cannot read file');
$names = array();
$rows = array();

//build array of surnames, and array of rows
while (false != ( $row = fgetcsv($GuestBook, 0, ',') )) {
    //extract surname from the first column
    //this should match the last word before the comma, if there is a comma
    preg_match('~([^\s]+)(?:,.*)?$~', $row[0], $m);
    $names[] = $m[1];
    $rows[] = $row;
}

fclose($GuestBook);

//sort array of rows by surname using our array of surnames
array_multisort($names, $rows);

//Remove duplicate names.
array_unique($names);

$GuestBook = fopen('GuestBook.csv', 'w') or die('cannot read file');

foreach ($rows as $line)
{
    fputcsv($GuestBook,$line);
}
fclose($GuestBook);
//you could write $rows back to a file here if you wanted.
?>