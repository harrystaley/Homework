Ppblic class QueueInfo{
    //declare instance fields to represent a shoper's name and their grocery bill.
    Private String name;
    Private double bill;

    public QueueInfo(String newName, double newBill)
    {
        name = newName;
        bill = newBill;
    } // end contructor QueueInfo

} // end class QueueInfo