
public class BSTNode {
    private int info;  // single piece of information
    
    public BSTNode(int newInfo)
    {
        info = newInfo;
    }   // end constructor BSTNode
    
    public int returnInfo()
    {
        return info;
    }   // end method returnInfo
    
}   // end class BSTNode
